export default function handleGenerateDocument(id) {
    alert('Document generated based on the current quotes. ' + id)
  }