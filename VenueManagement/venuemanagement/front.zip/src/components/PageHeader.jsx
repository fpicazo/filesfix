import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Bell,
  User,
  Settings,
  Gift,
  MessageCircle,
  ShoppingCart,
} from "lucide-react";
import ArrowRightBigIcon from "../assets/helperIcons/ArrowRightBigIcon";
import NotificationsIcon from "../assets/helperIcons/NotificationsIcon";
import HelpIcon from "../assets/helperIcons/HelpIcon";

const PageHeader = ({ title, backPath, actions, children }) => {
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const notificationRef = useRef(null);

  // Sample notifications data
  const notifications = [
    {
      id: 1,
      type: "achievement",
      icon: <Gift className="w-4 h-4 text-yellow-500" />,
      avatar: "/api/placeholder/32/32",
      title: "Congratulation Lettie 🎉",
      description: "Won the monthly best seller gold badge",
      time: "1h ago",
      unread: true,
    },
    {
      id: 2,
      type: "connection",
      avatar: "CF",
      title: "Charles Franklin",
      description: "Accepted your connection",
      time: "12hr ago",
      unread: true,
    },
    {
      id: 3,
      type: "message",
      icon: <MessageCircle className="w-4 h-4 text-blue-500" />,
      avatar: "/api/placeholder/32/32",
      title: "New Message 💬",
      description: "You have new message from Natalie",
      time: "1h ago",
      unread: false,
    },
    {
      id: 4,
      type: "order",
      icon: <ShoppingCart className="w-4 h-4 text-green-500" />,
      title: "Whoo! You have new order 🛒",
      description: "ACME Inc. made new order $1,154",
      time: "1 day ago",
      unread: true,
    },
  ];

  const unreadCount = notifications.filter((n) => n.unread).length;

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setShowNotifications(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getNotificationIcon = (notification) => {
    if (notification.icon) {
      return (
        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
          {notification.icon}
        </div>
      );
    }
    return null;
  };

  const getAvatar = (notification) => {
    if (notification.avatar && notification.avatar.startsWith("/")) {
      return (
        <img
          src={notification.avatar}
          alt="User"
          className="w-8 h-8 rounded-full object-cover"
        />
      );
    } else if (notification.avatar) {
      return (
        <div className="w-8 h-8 bg-orange-200 text-orange-800 rounded-full flex items-center justify-center text-sm font-medium">
          {notification.avatar}
        </div>
      );
    }
    return (
      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
        <User className="w-4 h-4 text-gray-500" />
      </div>
    );
  };

  return (
    <div className="flex flex-col flex-1 min-h-0">
      <header className="bg-white border-b border-gray-200 py-4 sticky top-0 z-20">
        <div className="flex items-center justify-between px-6 mx-auto">
          {/* Left section: back button + title */}
          <div className="flex items-center gap-4">
            {backPath && (
              // <button
              //   onClick={() => navigate(backPath)}
              //   className="flex items-center gap-1 text-gray-600 hover:text-purple-700 transition-colors"
              // >
              //    <ArrowRightBigIcon />
              //   <span>Back</span>
              // </button>
              <button
                onClick={() => navigate(backPath)}
                className="border rounded-full w-[26px] h-[26px] flex justify-center items-center"
              >
                <ArrowRightBigIcon />
              </button>
            )}
            <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
          </div>

          {/* Right section: actions + notification + account */}
          <div className="flex items-center gap-4">
            {/* Page-specific actions */}
            {/* {actions && (
              <div className="flex items-center gap-2">{actions}</div>
            )} */}

            {/* Notification and Account Icons */}
            <div className="flex items-center gap-2 ml-4 pl-4">
              {/* Notification Icon with Dropdown */}
              <div className="relative" ref={notificationRef}>
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative w-10 h-10 flex items-center justify-center text-gray-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors"
                  title="Notifications"
                >
                  {/* <Bell className="w-5 h-5" /> */}
                  <NotificationsIcon />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center font-medium">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notification Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                    {/* Header */}
                    <div className="flex items-center justify-between p-4 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold text-gray-900">
                          Notification
                        </h3>
                        <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full font-medium">
                          {unreadCount} New
                        </span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600">
                        <Settings className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Notifications List */}
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className="flex items-start gap-3 p-4 hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0"
                        >
                          <div className="flex-shrink-0 relative">
                            {getNotificationIcon(notification) ||
                              getAvatar(notification)}
                            {notification.icon && notification.avatar && (
                              <div className="absolute -top-1 -right-1">
                                {getNotificationIcon(notification)}
                              </div>
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {notification.title}
                            </p>
                            <p className="text-sm text-gray-600 mt-1">
                              {notification.description}
                            </p>
                            <p className="text-xs text-gray-400 mt-2">
                              {notification.time}
                            </p>
                          </div>

                          {notification.unread && (
                            <div className="flex-shrink-0">
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="p-3 border-t border-gray-100">
                      <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors">
                        View all notifications
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <button
  className="w-10 h-10 flex items-center justify-center text-gray-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors"
  title="Help"
>
  <HelpIcon />
</button>

              {/* Account Icon */}
              <button
                className="w-10 h-10 flex items-center justify-center text-gray-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors"
                title="Account"
              >
                <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                  JD
                </div>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto min-h-0">
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
};

export default PageHeader;
