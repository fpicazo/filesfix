import axios from 'axios';

// Create a base axios instance
const http = axios.create({
  baseURL: 'http://localhost:3000/', // Change to your actual API URL
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token and user info to each request
http.interceptors.request.use(
  (config) => {
    // Get token from storage (localStorage or sessionStorage)
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    
    // Get user data from storage if available
    const userString = localStorage.getItem('userData');
    let userId = null;
    let tenantId = null;
    
    if (userString) {
      try {
        const userData = JSON.parse(userString);
        userId = userData.userId;
        tenantId = userData.tenantId;
      } catch (error) {
        console.error('Error parsing user data:', error);
      }
    }
    
    // Add token to headers if it exists
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    
    // Add user and tenant IDs to headers if they exist
    if (userId) {
      config.headers['userId'] = userId;
    }
    
    if (tenantId) {
      config.headers['tenantId'] = tenantId;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle token refresh or common error patterns
http.interceptors.response.use(
  (response) => {
    // Extract user and tenant IDs from response headers if they exist
    const userId = response.headers['userId'];
    const tenantId = response.headers['tenantId'];
    
    // Store user info if it's included in auth-related responses
    if (response.data?.user) {
      const userData = {
        userId: response.data.user.userId || userId,
        tenantId: response.data.user.tenantId || tenantId,
        // Add other user properties as needed
      };
      
      // Store the user data in localStorage for future requests
      localStorage.setItem('userData', JSON.stringify(userData));
    }
    
    return response;
  },
  async (error) => {
    // Handle token expiration and refresh logic here if needed
    // Example: if (error.response.status === 401) { /* refresh token logic */ }
    
    return Promise.reject(error);
  }
);

export default http;