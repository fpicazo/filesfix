import React, { useState, useEffect } from 'react'
import http from '../config/http'
import { Calendar, Users, FileText, CreditCard, BarChart3, TrendingUp, DollarSign, Filter } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import PageHeader from '../components/PageHeader'


const Analytics = () => {
  const [analyticsData, setAnalyticsData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [dateFilter, setDateFilter] = useState('all')
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchAnalyticsData()
  }, [dateFilter])

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      const response = await http.get(`/api/analytics?dateFilter=${dateFilter}`)
      setAnalyticsData(response.data)
      setError(null)
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to fetch analytics data')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">Error loading analytics: {error}</p>
          <button 
            onClick={fetchAnalyticsData}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  const { summary, eventsByMonth, quotesByStatus, eventsRoi, topCustomers, eventsByGuests } = analyticsData

  // Prepare chart data
  const monthlyData = Object.entries(eventsByMonth || {}).map(([month, events]) => ({
    month,
    events: events.length,
    revenue: events.reduce((sum, event) => sum + (event.amount || 0), 0)
  }))

  const roiData = Object.entries(eventsRoi || {}).map(([month, data]) => ({
    month,
    income: data.income,
    expenses: data.expenses,
    roi: data.roi
  }))

  const quoteStatusData = Object.entries(quotesByStatus || {}).map(([status, quotes]) => ({
    name: status.charAt(0).toUpperCase() + status.slice(1),
    value: quotes.length,
    amount: quotes.reduce((sum, quote) => sum + (quote.amount || 0), 0)
  }))

  const guestData = (eventsByGuests || []).slice(0, 10).map(item => ({
    guests: `${item._id} guests`,
    events: item.totalEvents,
    revenue: item.totalAmount
  }))

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#8dd1e1', '#d084d0']

  const StatCard = ({ title, value, subtitle, icon: Icon, color, trend }) => (
    <div className="bg-white border border-gray-200 rounded-lg p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
      {trend && (
        <div className="mt-2 flex items-center">
          <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
          <span className="text-sm text-green-600">{trend}</span>
        </div>
      )}
    </div>
  )

  const actions = (
    // empty actions for now
    <div ></div>

  )

  return (
    <PageHeader title="Analytics" backPath="/" actions={actions}>
    <div className="p-6">
      {/* Header */}
      
      <div className="flex justify-between items-center mb-6">
 
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <select 
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 text-sm"
          >
            <option value="all">All Time</option>
            <option value="2024-01-01">This Year</option>
            <option value="2024-10-01">Last 3 Months</option>
            <option value="2024-11-01">Last 2 Months</option>
            <option value="2024-12-01">This Month</option>
          </select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Revenue"
          value={`$${(summary?.totalRevenue || 0).toLocaleString()}`}
          subtitle={`Net: $${((summary?.totalRevenue || 0) - (summary?.totalExpenses || 0)).toLocaleString()}`}
          icon={DollarSign}
          color="bg-green-100 text-green-800"
        />
        <StatCard
          title="Total Events"
          value={summary?.totalEvents || 0}
          subtitle={`${summary?.totalCustomers || 0} customers`}
          icon={Calendar}
          color="bg-blue-100 text-blue-800"
        />
        <StatCard
          title="Active Quotes"
          value={summary?.totalQuotes || 0}
          subtitle="Pending approval"
          icon={FileText}
          color="bg-amber-100 text-amber-800"
        />
        <StatCard
          title="Total Expenses"
          value={`$${(summary?.totalExpenses || 0).toLocaleString()}`}
          subtitle="Operating costs"
          icon={CreditCard}
          color="bg-red-100 text-red-800"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Monthly Events & Revenue */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Monthly Events & Revenue</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Bar yAxisId="left" dataKey="events" fill="#8884d8" name="Events" />
              <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#82ca9d" name="Revenue ($)" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* ROI Analysis */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Monthly ROI Analysis</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={roiData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
              <Legend />
              <Bar dataKey="income" fill="#82ca9d" name="Income" />
              <Bar dataKey="expenses" fill="#ff7300" name="Expenses" />
              <Bar dataKey="roi" fill="#8884d8" name="ROI" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Quote Status Distribution */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Quote Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={quoteStatusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {quoteStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Events by Guest Count */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Events by Guest Count</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={guestData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="guests" type="category" width={80} />
              <Tooltip />
              <Bar dataKey="events" fill="#8884d8" name="Events" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Customers Table */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Top Customers</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Events</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Guests</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Revenue</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {(topCustomers || []).map((customer, index) => (
                <tr key={customer._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-8 w-8 bg-indigo-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-indigo-800">{index + 1}</span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.eventCount}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.totalGuests || 0}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${(customer.totalAmount || 0).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </PageHeader>
  )
}

export default Analytics