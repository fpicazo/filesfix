import React, { useState, useEffect, useRef } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Plus, X, Edit2, ArrowLeft, Camera, Upload } from 'lucide-react'
import http from '../config/http'
import { formatDateToDMY } from '../utils/formatDate'
import FileImport from '../components/shared/FileList'
import uploadFileToS3 from '../utils/uploadFileToS3'

export default function CustomerDetail() {
  const [customer, setCustomer] = useState({})
  const { id } = useParams()
  const fileInputRef = useRef(null)

  const [activeTab, setActiveTab] = useState("events")
  const [editingNotes, setEditingNotes] = useState(false)
  const [notesDraft, setNotesDraft] = useState("")
  const [eventsData, setEventsData] = useState([])
  const [quotesData, setQuotesData] = useState([])

  const [uploadingImage, setUploadingImage] = useState(false)
  const [imageError, setImageError] = useState('')

  const [editingDetails, setEditingDetails] = useState(false)
  const [detailsDraft, setDetailsDraft] = useState({
    name: '',
    subText: '',
    email: '',
    phone: '',
    address: '',
    imageUrl: ''
  })

  useEffect(() => {
    const fetchCustomer = async () => {
      try {
        const response = await http.get('/api/customers/' + id)
        console.log(response.data)
        setCustomer(response.data)
        setNotesDraft(response.data.notes)
        setDetailsDraft({
          name: response.data.name,
          subText: response.data.subText,
          email: response.data.email,
          phone: response.data.phone,
          address: response.data.address,
          imageUrl: response.data.imageUrl
        })
        setEventsData(response.data?.related?.events || [])
        setQuotesData(response.data?.related?.quotes || [])
      } catch (error) {
        console.error("Error fetching customer data:", error)
      }
    }
    fetchCustomer()
  }, [id])

  const getInitials = (name = "") => {
    const parts = name.trim().split(" ")
    const first = parts[0]?.[0] || ""
    const second = parts[1]?.[0] || ""
    return (first + second).toUpperCase()
  }

  const handleImageSelect = (event) => {
    const file = event.target.files[0]
    if (file) {
      handleImageUpload(file)
    }
  }

  const handleImageUpload = async (file) => {
    if (!file.type.startsWith('image/')) {
      setImageError('Please select a valid image file')
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      setImageError('Image size must be less than 5MB')
      return
    }

    setUploadingImage(true)
    setImageError('')

    try {
      const imageUrl = await uploadFileToS3({
        file,
        module: 'customers',
        recordId: id,
        tenantId: customer.tenantId,
        tipo: "profile",
      })

      await http.put('/api/customers/' + id, { imageUrl })
      
      setCustomer(prev => ({ ...prev, imageUrl }))
      setDetailsDraft(prev => ({ ...prev, imageUrl }))
      
      console.log('Customer image updated successfully')
    } catch (error) {
      console.error('Error uploading image:', error)
      setImageError('Failed to upload image. Please try again.')
    } finally {
      setUploadingImage(false)
    }
  }

  const handleSaveNotes = () => {
    setCustomer(prev => ({ ...prev, notes: notesDraft }))
    setEditingNotes(false)
    try {
      http.put('/api/customers/' + id, { notes: notesDraft })
    } catch (error) {
      console.error("Error saving customer notes:", error)
    }
  }

  const handleSaveDetails = () => {
    setCustomer(prev => ({
      ...prev,
      name: detailsDraft.name,
      subText: detailsDraft.subText,
      email: detailsDraft.email,
      phone: detailsDraft.phone,
      address: detailsDraft.address,
      imageUrl: detailsDraft.imageUrl
    }))
    setEditingDetails(false)
    try {
      http.put('/api/customers/' + id, {
        name: detailsDraft.name,
        subText: detailsDraft.subText,
        email: detailsDraft.email,
        phone: detailsDraft.phone,
        address: detailsDraft.address,
        imageUrl: detailsDraft.imageUrl
      })
    } catch (error) {
      console.error("Error saving customer details:", error)
    }
  }

  const renderTable = () => {
    if (activeTab === "events") {
      return (
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-gray-500">
              <th className="py-2">Name</th>
              <th className="py-2">Date</th>
              <th className="py-2">Type</th>
              <th className="py-2">Guests</th>
              <th className="py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {eventsData.map(evt => (
              <tr key={evt.id} className="border-b last:border-none hover:bg-purple-50 transition-colors">
                <td className="py-3">{evt.name}</td>
                <td className="py-3">{formatDateToDMY(evt.date)}</td>
                <td className="py-3">{evt.type}</td>
                <td className="py-3 text-center">{evt.guests}</td>
                <td className="py-3">
                  <span className={`font-medium ${
                    evt.status === "Confirmed" ? "text-green-600" : 
                    evt.status === "Pending" ? "text-orange-600" :
                    evt.status === "Completed" ? "text-blue-600" :
                    evt.status === "Cancelled" ? "text-red-600" : "text-gray-600"
                  }`}>
                    {evt.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )
    } 
    else if (activeTab === "attachments") {
      return (
        <FileImport module="customers" parentId={id} tenantId={customer.tenantId} files={customer?.related?.attachments} />
      )
    } 
    else {
      return (
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-gray-500">
              <th className="py-2">Referencia</th>
              <th className="py-2">Date</th>
              <th className="py-2">Amount</th>
              <th className="py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {quotesData.map(quote => (
              <tr key={quote.id} className="border-b last:border-none hover:bg-purple-50 transition-colors">
                <td className="py-3">{quote.quoteNumber}</td>
                <td className="py-3">{formatDateToDMY(quote.date)}</td>
                <td className="py-3">{quote.amount}</td>
                <td className="py-3">
                  <span className="font-medium text-green-600">
                    {quote.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )
    }
  }

  return (
    <div className="min-h-screen bg-purple-50">
      {/* Header with back arrow */}
      <header className="bg-white border-b border-purple-500">
        <div className="px-6 py-4 flex items-center gap-4">
          <Link to="/customers" className="text-purple-600 hover:text-purple-800">
            <ArrowLeft className="h-6 w-6" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-800">Customer Details</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Top Section: Customer Info & Notes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Card: Customer Information */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-gray-800">Customer Information</h2>
              <button
                onClick={() => {
                  setEditingDetails(true)
                  setDetailsDraft({
                    name: customer.name,
                    subText: customer.subText,
                    email: customer.email,
                    phone: customer.phone,
                    address: customer.address,
                    imageUrl: customer.imageUrl
                  })
                }}
                className="text-purple-600 hover:text-purple-800"
              >
                <Edit2 className="h-5 w-5" />
              </button>
            </div>
            <div className="flex items-center gap-4 mb-4">
              {/* Avatar with image upload */}
              <div className="relative">
                {customer.imageUrl || detailsDraft.imageUrl ? (
                  <img
                    src={customer.imageUrl || detailsDraft.imageUrl}
                    alt={customer.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-gray-200"
                  />
                ) : (
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center text-xl font-semibold ${customer.avatarColor || "bg-purple-600"} text-white`}>
                    {getInitials(customer.name)}
                  </div>
                )}
                
                {/* Upload button overlay */}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingImage}
                  className="absolute -bottom-1 -right-1 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white rounded-full p-1.5 transition-colors"
                  title="Upload image"
                >
                  {uploadingImage ? (
                    <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Camera className="h-3 w-3" />
                  )}
                </button>
                
                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  className="hidden"
                />
              </div>
              
              {editingDetails ? (
                <div className="flex-1 space-y-2">
                  <input
                    type="text"
                    value={detailsDraft.name}
                    onChange={(e) => setDetailsDraft({ ...detailsDraft, name: e.target.value })}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <input
                    type="text"
                    value={detailsDraft.subText}
                    onChange={(e) => setDetailsDraft({ ...detailsDraft, subText: e.target.value })}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="Sub Text"
                  />
                </div>
              ) : (
                <div>
                  <p className="text-gray-800 font-semibold">{customer.name}</p>
                  {customer.subText && (
                    <p className="text-sm text-gray-500">{customer.subText}</p>
                  )}
                </div>
              )}
            </div>
            
            {/* Image upload error */}
            {imageError && (
              <div className="mb-4 p-2 bg-red-100 border border-red-300 text-red-700 rounded-md text-sm">
                {imageError}
              </div>
            )}
            
            <div className="space-y-4 text-sm">
              {editingDetails ? (
                <>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={detailsDraft.email}
                      onChange={(e) => setDetailsDraft({ ...detailsDraft, email: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                      Phone
                    </label>
                    <input
                      type="text"
                      value={detailsDraft.phone}
                      onChange={(e) => setDetailsDraft({ ...detailsDraft, phone: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                      Address
                    </label>
                    <input
                      type="text"
                      value={detailsDraft.address}
                      onChange={(e) => setDetailsDraft({ ...detailsDraft, address: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <button
                      onClick={() => {
                        setEditingDetails(false)
                        setDetailsDraft({
                          name: customer.name,
                          subText: customer.subText,
                          email: customer.email,
                          phone: customer.phone,
                          address: customer.address,
                          imageUrl: customer.imageUrl
                        })
                      }}
                      className="flex-1 border border-gray-300 text-gray-700 hover:bg-gray-50 py-2.5 rounded-lg font-medium transition-colors text-sm"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveDetails}
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg font-medium transition-colors text-sm"
                    >
                      Save Changes
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Email</p>
                    <p className="text-gray-800 mt-1">{customer.email}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</p>
                    <p className="text-gray-800 mt-1">{customer.phone}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Address</p>
                    <p className="text-gray-800 mt-1">{customer.address}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Customer Since</p>
                    <p className="text-gray-800 mt-1">{formatDateToDMY(customer.createdAt)}</p>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right Card: Notes */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-gray-800">Notes</h2>
              <button
                onClick={() => setEditingNotes(!editingNotes)}
                className="text-purple-600 hover:text-purple-800"
              >
                <Edit2 className="h-5 w-5" />
              </button>
            </div>
            {editingNotes ? (
              <>
                <textarea
                  value={notesDraft}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  rows="8"
                  placeholder="Add notes about this customer..."
                />
                <div className="flex gap-3 pt-4 border-t border-gray-200 mt-4">
                  <button
                    onClick={() => { setEditingNotes(false); setNotesDraft(customer.notes) }}
                    className="flex-1 border border-gray-300 text-gray-700 hover:bg-gray-50 py-2.5 rounded-lg font-medium transition-colors text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveNotes}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg font-medium transition-colors text-sm"
                  >
                    Save Notes
                  </button>
                </div>
              </>
            ) : (
              <p className="text-sm text-gray-600">{customer.notes || 'No notes added yet.'}</p>
            )}
          </div>
        </div>

        {/* Tabs for switching between Events and Quotes */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 pt-6 pb-4">
            <div className="flex space-x-2 border-b border-gray-200">
              <button
                onClick={() => setActiveTab("events")}
                className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                  activeTab === "events"
                    ? "text-purple-600"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Events
                {activeTab === "events" && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600" />
                )}
              </button>
              <button
                onClick={() => setActiveTab("quotes")}
                className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                  activeTab === "quotes"
                    ? "text-purple-600"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Quotes
                {activeTab === "quotes" && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600" />
                )}
              </button>
              <button
                onClick={() => setActiveTab("attachments")}
                className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                  activeTab === "attachments"
                    ? "text-purple-600"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Attachments
                {activeTab === "attachments" && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600" />
                )}
              </button>
            </div>
          </div>
          <div className="px-6 pb-6">
            {renderTable()}
          </div>
        </div>
      </div>
    </div>
  )
}