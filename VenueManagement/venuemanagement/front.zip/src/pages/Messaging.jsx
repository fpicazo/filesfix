import { useState,useEffect } from 'react' 
import PageHeader from '../components/PageHeader'
import { Plus } from 'lucide-react'
import EmailCompose from '../components/EmailCompose'



const Messaging = () => {
const [showCompose, setShowCompose] = useState(false)

  const toggleCompose = () => {
    setShowCompose(!showCompose)
  }


  const actions = (
  <button className="px-4 py-2 bg-purple-600 text-white rounded
  hover:bg-purple-700 transition-colors" onClick={toggleCompose}>
    <Plus className="h-4 w-4 inline-block mr-1" />
    New Message
  </button>
)

  return (
     <PageHeader title="Messaging" backPath="/" actions={actions}>
    <div>Messaging</div>
    {showCompose && <EmailCompose onClose={toggleCompose} />}
    </PageHeader>
  )
}

export default Messaging