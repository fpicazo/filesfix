import React, { useState, useEffect } from 'react'
import { Plus, DollarSign, Pencil, Trash } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { formatDateToDMY } from '../utils/formatDate'
import PageHeader from '../components/PageHeader'
import DrawerWrapper from '../components/DrawerWrapper'
import { CustomTable } from '../components/Table/CustomTable'
import http from '../config/http'
import FileImport from '../components/shared/FileList'

export default function PaymentsPage() {
  // State variables
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [paymentsList, setPaymentsList] = useState([])
  const [editingPayment, setEditingPayment] = useState(null)
  const [customersList, setCustomersList] = useState([])
  const [customerInvoices, setCustomerInvoices] = useState([])
  const [selectedInvoice, setSelectedInvoice] = useState(null)
  
  const [formData, setFormData] = useState({
    customerId: "",
    invoiceId: "",
    paymentDate: new Date().toISOString().split('T')[0],
    amountToPay: "",
    paymentMethod: "",
    reference: "",
    notes: "",
    balanceBefore: null,
    balanceAfter: null
  })

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const { data } = await http.get('/api/payments')
        console.log("Fetched payments:", data)
        setPaymentsList(data)
      } catch (error) {
        console.error("Error fetching payments:", error)
      }
    }
    
    const fetchCustomers = async () => {
      try {
        const { data } = await http.get('/api/customers')
        setCustomersList(data)
      } catch (error) {
        console.error("Error fetching customers:", error)
      }
    }
    
    fetchPayments()
    fetchCustomers()
  }, [])

  // Fetch customer invoices when customer is selected
  const handleCustomerChange = async (customerId) => {
    setFormData(prev => ({
      ...prev,
      customerId,
      invoiceId: "",
      amountToPay: ""
    }))
    
    setSelectedInvoice(null)
    setCustomerInvoices([])
    
    if (customerId) {
      try {
        const { data } = await http.get(`/api/invoices?customerId=${customerId}`)
        // Filter for unpaid or partially paid invoices
        const unpaidInvoices = data.filter(invoice => 
          invoice.status === 'pending' || invoice.status === 'partial'
        )
        setCustomerInvoices(unpaidInvoices)
      } catch (error) {
        console.error("Error fetching customer invoices:", error)
        setCustomerInvoices([])
      }
    }
  }

  // Handle invoice selection
  const handleInvoiceChange = (invoiceId) => {
    const invoice = customerInvoices.find(inv => inv._id === invoiceId)
    setSelectedInvoice(invoice)
    setFormData(prev => ({
      ...prev,
      invoiceId,
      amountToPay: invoice ? invoice.balance.toString() : ""
    }))
  }

  // Get balance before - use saved value if editing, otherwise use current balance
  const getBalanceBefore = () => {
    if (editingPayment && formData.balanceBefore !== null) {
      return formData.balanceBefore
    }
    return selectedInvoice?.balance || 0
  }

  // Calculate amount after payment - use saved value if editing, otherwise calculate
  const getBalanceAfter = () => {
    if (editingPayment && formData.balanceAfter !== null) {
      return formData.balanceAfter
    }
    
    const balanceBefore = getBalanceBefore()
    const amountToPay = parseFloat(formData.amountToPay) || 0
    return Math.max(0, balanceBefore - amountToPay)
  }

  // Handle form submission
  const handleFormSubmit = async (e) => {
    e.preventDefault()
    
    const paymentData = {
      ...formData,
      amountToPay: parseFloat(formData.amountToPay),
      balanceBefore: getBalanceBefore(),
      balanceAfter: getBalanceAfter()
    }
    
    if (editingPayment) {
      // Update existing payment in local state
      setPaymentsList(prev =>
        prev.map(payment =>
          payment._id === editingPayment._id ? { ...payment, ...paymentData } : payment
        )
      )
      try {
        await http.put(`/api/payments/${editingPayment._id}`, paymentData)
      } catch (error) {
        console.error("Error updating payment:", error)
      }
    } else {
      // Add new payment
      try {
        const { data: newPayment } = await http.post('/api/payments', paymentData)
        setPaymentsList(prev => [...prev, newPayment])
      } catch (error) {
        console.error("Error adding payment:", error)
      }
    }

    closeDrawer()
  }

  const deletePayment = async (id) => {
    if (window.confirm('Are you sure you want to delete this payment?')) {
      setPaymentsList(prev => prev.filter(payment => payment._id !== id))
      try {
        await http.delete(`/api/payments/${id}`)
      } catch (error) {
        console.error("Error deleting payment:", error)
      }
    }
  }

  const openDrawer = async (payment = null) => {
    if (payment) {
      const paymentDate = payment.paymentDate
        ? payment.paymentDate.split('T')[0]
        : new Date().toISOString().split('T')[0]

      const customerId = payment.invoiceId?.customerId?._id
      const invoiceId = payment.invoiceId?._id

      if (customerId) {
        await handleCustomerChange(customerId)
      }

      setEditingPayment(payment)
      setFormData({
        customerId: customerId || '',
        invoiceId: invoiceId || '',
        paymentDate,
        amountToPay: payment.amount?.toString() || '',
        paymentMethod: payment.method || '',
        reference: payment.reference || '',
        notes: payment.notes || '',
        balanceBefore: payment.balanceBefore ?? null,
        balanceAfter: payment.balanceAfter ?? null
      })

      setSelectedInvoice({
        balance: payment.invoiceId?.balance ?? 0,
        ...payment.invoiceId,
      })
    } else {
      setFormData({
        customerId: '',
        invoiceId: '',
        paymentDate: new Date().toISOString().split('T')[0],
        amountToPay: '',
        paymentMethod: '',
        reference: '',
        notes: '',
        balanceBefore: null,
        balanceAfter: null
      })
      setSelectedInvoice(null)
      setCustomerInvoices([])
      setEditingPayment(null)
    }

    setDrawerOpen(true)
  }

  const closeDrawer = () => {
    setDrawerOpen(false)
    setEditingPayment(null)
    setSelectedInvoice(null)
    setCustomerInvoices([])
    setFormData({
      customerId: "",
      invoiceId: "",
      paymentDate: new Date().toISOString().split('T')[0],
      amountToPay: "",
      paymentMethod: "",
      reference: "",
      notes: "",
      balanceBefore: null,
      balanceAfter: null
    })
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const getPaymentMethodBadge = (method) => {
    const methodColors = {
      'Cash': 'bg-green-100 text-green-800',
      'Credit Card': 'bg-blue-100 text-blue-800',
      'Bank Transfer': 'bg-purple-100 text-purple-800',
      'Check': 'bg-yellow-100 text-yellow-800',
      'PayPal': 'bg-indigo-100 text-indigo-800',
      'Other': 'bg-gray-100 text-gray-800'
    }
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${methodColors[method] || 'bg-gray-100 text-gray-800'}`}>
        {method}
      </span>
    )
  }

  // Define columns for CustomTable
  const columns = [
    {
      header: "Payment Date",
      accessorKey: "date",
      cell: (props) => (
        <p className="text-gray-800">{formatDateToDMY(props.getValue())}</p>
      ),
      filterFn: "dateFilter",
      meta: { filterVariant: "date" }
    },
    {
      header: "Customer",
      accessorKey: "invoiceId.customerId.name",
      cell: ({ row }) => (
        <p className="text-gray-800 font-medium">
          {row.original.invoiceId?.customerId?.name || 'Unknown Customer'}
        </p>
      )
    },
    {
      header: "Invoice",
      accessorKey: "invoiceId.invoiceNumber",
      cell: (props) => (
        <p className="text-gray-800">{props.getValue() || 'N/A'}</p>
      )
    },
    {
      header: "Balance Before",
      accessorKey: "balanceBefore",
      cell: ({ row }) => (
        <p className="text-gray-600 text-sm">
          ${row.original.balanceBefore?.toFixed(2) ?? 'N/A'}
        </p>
      )
    },
    {
      header: "Amount Paid",
      accessorKey: "amount",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <p className="text-gray-800 font-semibold">${row.original.amount?.toFixed(2)}</p>
        </div>
      )
    },
    {
      header: "Balance After",
      accessorKey: "balanceAfter",
      cell: ({ row }) => (
        <p className="text-gray-600 text-sm font-medium">
          ${row.original.balanceAfter?.toFixed(2) ?? 'N/A'}
        </p>
      )
    },
    {
      header: "Method",
      accessorKey: "method",
      meta: { filterVariant: "select", defaultLabel: "All Methods" },
      cell: ({ row }) => getPaymentMethodBadge(row.original.method)
    },
    {
      header: "Reference",
      accessorKey: "reference",
      cell: (props) => (
        <p className="text-gray-600">{props.getValue() || '-'}</p>
      )
    },
    {
      header: "Action",
      isHideSort: true,
      cell: ({ row }) => (
        <div className="flex gap-2">
          <button
            onClick={() => openDrawer(row.original)}
            className="py-2 px-3 border shadow rounded-lg flex items-center gap-2"
            title="Edit Payment"
          >
            <Pencil size={14} />
          </button>
          <button
            onClick={() => deletePayment(row.original._id)}
            className="py-2 px-3 border shadow rounded-lg flex items-center gap-2"
            title="Delete Payment"
          >
            <Trash size={14} />
          </button>
        </div>
      )
    }
  ]

  return (
    <PageHeader title="Payments" backPath="/">
      <div className="min-h-screen bg-purple-50">
        {/* Main Content */}
        <div className="px-6 py-6">
          <div className="bg-white rounded-lg shadow p-4">
            <CustomTable
              data={paymentsList}
              columns={columns}
              dataNotFoundQuery="No payments found"
              additionalActions={
                <button
                  onClick={() => openDrawer()}
                  className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-md font-medium text-sm shadow"
                >
                  <Plus className="h-4 w-4" />
                  Add New Payment
                </button>
              }
            />
          </div>
        </div>

        {/* Drawer for Create/Edit Payment */}
        <DrawerWrapper
          open={drawerOpen}
          onClose={closeDrawer}
          title={editingPayment ? "Edit Payment" : "New Payment"}
        >
          <form onSubmit={handleFormSubmit} className="space-y-6">
            {/* Customer and Invoice Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900 border-b border-gray-200 pb-2">
                Customer & Invoice
              </h3>
              
              <div>
                <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                  Customer
                </label>
                <select
                  name="customerId"
                  value={formData.customerId}
                  onChange={(e) => handleCustomerChange(e.target.value)}
                  required
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Customer</option>
                  {customersList.map((customer) => (
                    <option key={customer._id} value={customer._id}>
                      {customer.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                  Invoice
                </label>
                <select
                  name="invoiceId"
                  value={formData.invoiceId}
                  onChange={(e) => handleInvoiceChange(e.target.value)}
                  required
                  disabled={!formData.customerId}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">Select Invoice</option>
                  {customerInvoices.map((invoice) => (
                    <option key={invoice._id} value={invoice._id}>
                      {invoice.invoiceNumber} - Balance: ${invoice.balance}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Payment Details Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900 border-b border-gray-200 pb-2">
                Payment Details
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                    Payment Date
                  </label>
                  <input
                    type="date"
                    name="paymentDate"
                    value={formData.paymentDate}
                    onChange={handleInputChange}
                    required
                    className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                    Payment Method
                  </label>
                  <select
                    name="paymentMethod"
                    value={formData.paymentMethod}
                    onChange={handleInputChange}
                    required
                    className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">Select Method</option>
                    <option value="Cash">Cash</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Check">Check</option>
                    <option value="PayPal">PayPal</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                  Reference Number
                </label>
                <input
                  type="text"
                  name="reference"
                  value={formData.reference}
                  onChange={handleInputChange}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Transaction reference or check number"
                />
              </div>
            </div>

            {/* Amount Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900 border-b border-gray-200 pb-2">
                Amount Information
              </h3>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                    Balance Before
                  </label>
                  <div className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm bg-gray-50 text-gray-700 font-medium">
                    ${getBalanceBefore().toFixed(2)}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                    Monto Pagado
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">$</span>
                    <input
                      type="number"
                      name="amountToPay"
                      value={formData.amountToPay}
                      onChange={handleInputChange}
                      required
                      min="0"
                      max={getBalanceBefore()}
                      step="0.01"
                      className="w-full border border-gray-200 rounded-lg pl-8 pr-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">
                    Balance After
                  </label>
                  <div className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm bg-green-50 text-green-700 font-medium">
                    ${getBalanceAfter().toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Show audit trail when editing */}
              {editingPayment && formData.balanceBefore !== null && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs">
                  <p className="text-blue-800 font-medium mb-1">Payment Record</p>
                  <p className="text-blue-700">
                    This payment reduced the balance from ${formData.balanceBefore.toFixed(2)} to ${formData.balanceAfter.toFixed(2)}
                  </p>
                </div>
              )}
            </div>

            {/* Notes Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900 border-b border-gray-200 pb-2">
                Notes
              </h3>
              
              <div>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                  placeholder="Payment notes or additional details..."
                />
              </div>
            </div>
            
            <FileImport module="payments" parentId={formData._id} files={formData?.related?.attachments} />

            {/* Action Buttons */}
            <div className="flex gap-3 pt-6 border-t border-gray-200">
              <button
                type="button"
                onClick={closeDrawer}
                className="flex-1 border border-gray-300 text-gray-700 hover:bg-gray-50 py-2.5 rounded-lg font-medium transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg font-medium transition-colors text-sm"
              >
                {editingPayment ? "Update Payment" : "Record Payment"}
              </button>
            </div>
          </form>
        </DrawerWrapper>
      </div>
    </PageHeader>
  )
}