import React, { useState, useEffect, useRef } from 'react';
import { Building2, Camera, User } from 'lucide-react';
import Integrations from '../components/Settings/Integrations';
import UserManagement from '../components/Settings/UserManagement';
import Subscription from '../components/Settings/Subscription';
import DynamicFieldsManagementPage from '../components/Settings/DynamicFieldsManagementPage';
import RoleManagementPage from '../components/Settings/RoleManagementPage';
import { useSettings } from '../contexts/SettingsContext';
import uploadFileToS3 from '../utils/uploadFileToS3'; // Adjust path as needed

const SettingsPage = () => {
  const { settings, updateSetting, loading } = useSettings();
  const [activeTab, setActiveTab] = useState('General');
  const [settingsData, setSettingsData] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [showSaveMessage, setShowSaveMessage] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageError, setImageError] = useState('');
  const settingsRef = useRef(null);
  const fileInputRef = useRef(null);

  // Update local settingsData whenever the context settings change
  useEffect(() => {
    //console.log('Settings from context:', settings);
    // Deep clone settings to break reference equality
    if (settings && typeof settings === 'object') {
      const newSettingsData = JSON.parse(JSON.stringify(settings));
      //console.log('Setting settingsData to:', newSettingsData);
      setSettingsData(newSettingsData);
      settingsRef.current = newSettingsData;
    }
  }, [settings]);

  // Debug output
  useEffect(() => {
    //console.log('Current settingsData state:', settingsData);
  }, [settingsData]);

  const handleChange = (field, value) => {
    //console.log(`Updating field '${field}' to:`, value);
    setSettingsData(prev => {
      const newData = { 
        ...prev, 
        [field]: value 
      };
      console.log('Updated settingsData will be:', newData);
      return newData;
    });
  };

  // Image upload functions
  const handleImageSelect = (event) => {
    const file = event.target.files[0]
    if (file) {
      handleImageUpload(file)
    }
  }

  const handleImageUpload = async (file) => {
    if (!file.type.startsWith('image/')) {
      setImageError('Please select a valid image file')
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      setImageError('Image size must be less than 5MB')
      return
    }

    setUploadingImage(true)
    setImageError('')

    try {
      const imageUrl = await uploadFileToS3({
        file,
        module: 'company',
        recordId: 'company-profile',
        tenantId: 'default' // You might want to get this from context
      })

      setSettingsData(prev => ({ ...prev, companyImageUrl: imageUrl }))
      console.log('Company image uploaded successfully')
    } catch (error) {
      console.error('Error uploading image:', error)
      setImageError('Failed to upload image. Please try again.')
    } finally {
      setUploadingImage(false)
    }
  }

  const handleRemovePhoto = () => {
    setSettingsData(prev => ({ ...prev, companyImageUrl: '' }))
    setImageError('')
  }

  const handleSaveSettings = async () => {
    setIsSaving(true);
    try {
      console.log('Saving settings:', settingsData);
      await updateSetting(settingsData);
      setShowSaveMessage(true);
      setTimeout(() => setShowSaveMessage(false), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const tabs = ['General', 'Agents', 'Integrations','Subscription','Dynamic Fields','Role Management', 'Message Templates'];

  // If still loading or there's no data yet, show loading
  if (loading) {
    return <div className="p-6 text-gray-500">Loading settings...</div>;
  }

  // Fallback to empty objects for individual settings if they don't exist
  const safeSettingsData = settingsData || {};

  // Debug state
  //console.log('Rendering with settingsData:', safeSettingsData);

  return (
    <div className="min-h-screen bg-purple-50">
       <header className="bg-white border-b border-purple-500">
              <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
                <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
              </div>
            </header>
      
      <div className="bg-white border-b border-gray-200">
       <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-2">
  <div className="flex space-x-4">
    {tabs.map(tab => (
      <button
        key={tab}
        className={`px-6 py-3 text-sm font-medium ${activeTab === tab ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
        onClick={() => setActiveTab(tab)}
      >
        {tab}
      </button>
    ))}
  </div>

  <div className="flex items-center space-x-4">
    {activeTab === 'General' && (
      <>
        {showSaveMessage && (
          <span className="text-green-600 text-sm">Settings saved successfully!</span>
        )}
        <button
          onClick={handleSaveSettings}
          disabled={isSaving}
          className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${isSaving ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700'} focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
        >
          {isSaving ? 'Saving...' : 'Save Settings'}
        </button>
      </>
    )}
  </div>
</div>
        
      </div>

      {/* Content Container - Different layouts for different tabs */}
      {activeTab === 'Agents' ? (
        // Full width for UserManagement
        <div className="bg-gray-50">
          <UserManagement settings={settingsData} updateSetting={updateSetting} />
        </div>
      ) : (
        // Constrained width for other tabs
        <div className="max-w-4xl mx-auto px-6 py-4">
          {activeTab === 'General' && (
            <>
              <h2 className="text-lg font-medium text-gray-700 mb-3">Company Information</h2>
              <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6 mb-6">
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                  <div className="flex items-center gap-3">
                    {/* Company Logo - Discrete */}
                    <div className="relative flex-shrink-0">
                      {safeSettingsData.companyImageUrl ? (
                        <img
                          src={safeSettingsData.companyImageUrl}
                          alt="Company Logo"
                          className="w-12 h-12 rounded-lg object-cover border border-gray-200"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center border border-gray-200">
                          <Building2 className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingImage}
                        className="absolute -bottom-1 -right-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400 text-white rounded-full p-1 transition-colors"
                        title="Upload company logo"
                      >
                        {uploadingImage ? (
                          <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Camera className="h-3 w-3" />
                        )}
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                      />
                    </div>
                    
                    {/* Company Name Input */}
                    <div className="flex-1">
                      <input
                        type="text"
                        value={safeSettingsData.name || ''}
                        onChange={(e) => handleChange('name', e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        placeholder="Enter your company name"
                      />
                    </div>
                    
                    {/* Remove Button - Only show if image exists */}
                    {safeSettingsData.companyImageUrl && (
                      <button
                        type="button"
                        onClick={handleRemovePhoto}
                        className="text-gray-400 hover:text-red-600 text-xs px-2"
                        title="Remove logo"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                  {imageError && (
                    <p className="text-sm text-red-600 mt-1">{imageError}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Click the camera icon to upload your company logo
                  </p>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
                  <input
                    type="email"
                    value={safeSettingsData.supportEmail || ''}
                    onChange={(e) => handleChange('supportEmail', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="support@yourcompany.com"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Business Hours</label>
                  <div className="flex gap-4">
                    <input
                      type="text"
                      placeholder="Start time (e.g. 9:00 AM)"
                      value={safeSettingsData.startTime || ''}
                      onChange={(e) => handleChange('startTime', e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                    <input
                      type="text"
                      placeholder="End time (e.g. 5:00 PM)"
                      value={safeSettingsData.endTime || ''}
                      onChange={(e) => handleChange('endTime', e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Time Zone</label>
                  <select
                    value={safeSettingsData.timeZone || ''}
                    onChange={(e) => handleChange('timeZone', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="">Select a time zone</option>
                    <option value="Eastern Time (ET)">Eastern Time (ET)</option>
                    <option value="Pacific Time (PT)">Pacific Time (PT)</option>
                    <option value="Mountain Time (MT)">Mountain Time (MT)</option>
                    <option value="Central Time (CT)">Central Time (CT)</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Asignacion</label>
                  <select
                    value={safeSettingsData.assignment_mode || ''}
                    onChange={(e) => handleChange('assignment_mode', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="single">Asignacion Admin</option>
                    <option value="carousel">Carusel</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Visibility</label>
                  <select
                    value={safeSettingsData.visibility || ''}
                    onChange={(e) => handleChange('visibility', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="all">Universal</option>
                    <option value="own">Private</option>
                  </select>
                </div>
              </div>

              <h2 className="text-lg font-medium text-gray-700 mb-3">Notification Settings</h2>
              <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
                {['emailNotif', 'desktopNotif', 'soundNotif']
    .filter(key => key !== 'emailNotif' && key !== 'desktopNotif')
    .map((key) => (
                  <div key={key} className="flex justify-between items-center mb-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">
                        {key === 'emailNotif' ? 'Email Notifications' : 
                         key === 'desktopNotif' ? 'Desktop Notifications' : 
                         'Sound Notifications'}
                      </h3>
                      <p className="text-xs text-gray-500">
                        Toggle {key === 'emailNotif' ? 'email' : 
                                key === 'desktopNotif' ? 'desktop' : 
                                'sound'} notifications
                      </p>
                    </div>
                    
                    <div className="relative inline-block w-10 mr-2 align-middle select-none">
                      <input
                        type="checkbox"
                        id={`toggle-${key}`}
                        checked={Boolean(safeSettingsData[key])}
                        onChange={() => handleChange(key, !safeSettingsData[key])}
                        className="sr-only"
                      />
                      <label 
                        htmlFor={`toggle-${key}`}
                        className={`block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer ${
                          safeSettingsData[key] ? 'bg-indigo-600' : ''
                        }`}
                      >
                        <span className={`block h-6 w-6 rounded-full bg-white shadow transform transition-transform ${
                          safeSettingsData[key] ? 'translate-x-4' : 'translate-x-0'
                        }`}></span>
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {activeTab === 'Integrations' && (
            <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
              <Integrations settings={settingsData} updateSetting={updateSetting} />
            </div>
          )}
          {activeTab === 'Dynamic Fields' && (
            <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
              <DynamicFieldsManagementPage />
            </div>
          )}

          {activeTab === 'Message Templates' && (
            <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
              <p className="text-gray-500">Message templates configuration will appear here.</p>
            </div>
          )}
          
          {activeTab === 'Subscription' && (
            <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
              <Subscription settings={settingsData} updateSetting={updateSetting} />
            </div>
          )}

          {activeTab === 'Role Management' && (
            <div className="bg-white rounded-md shadow-sm border border-gray-200 p-6">
              <RoleManagementPage />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SettingsPage;